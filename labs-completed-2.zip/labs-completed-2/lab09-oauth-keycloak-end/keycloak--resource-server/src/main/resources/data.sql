INSERT INTO Project(id, name, date_created) VALUES (1, 'Project 1', '2019-06-13');
INSERT INTO Project(id, name, date_created) VALUES (2, 'Project 2', '2019-06-14');
INSERT INTO Project(id, name, date_created) VALUES (3, 'Project 3', '2019-06-15');

