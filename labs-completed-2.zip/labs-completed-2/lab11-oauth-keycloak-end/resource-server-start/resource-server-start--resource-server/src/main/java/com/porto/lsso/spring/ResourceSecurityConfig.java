package com.porto.lsso.spring;

import org.springframework.context.annotation.Configuration;

@Configuration
public class ResourceSecurityConfig {

}
