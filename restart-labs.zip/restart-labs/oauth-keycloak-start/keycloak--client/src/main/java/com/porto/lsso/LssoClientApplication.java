package com.porto.lsso;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LssoClientApplication {

    public static void main(String[] args) {
        SpringApplication.run(LssoClientApplication.class, args);
    }
}
