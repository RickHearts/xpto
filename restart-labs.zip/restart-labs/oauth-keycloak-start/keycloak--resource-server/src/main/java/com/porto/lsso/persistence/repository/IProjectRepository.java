package com.porto.lsso.persistence.repository;

import org.springframework.data.repository.PagingAndSortingRepository;

import com.porto.lsso.persistence.model.Project;

public interface IProjectRepository extends PagingAndSortingRepository<Project, Long> {
}
