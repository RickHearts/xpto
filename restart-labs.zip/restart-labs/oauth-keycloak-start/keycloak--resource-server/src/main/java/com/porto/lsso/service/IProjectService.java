package com.porto.lsso.service;

import java.util.Optional;

import com.porto.lsso.persistence.model.Project;

public interface IProjectService {
    Optional<Project> findById(Long id);

    Project save(Project project);

    Iterable<Project> findAll();

}
